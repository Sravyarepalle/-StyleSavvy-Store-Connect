package com.store.Style_Savvy.repository;
import com.store.Style_Savvy.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CustomerRepository extends JpaRepository<Customer, Integer> {
}
