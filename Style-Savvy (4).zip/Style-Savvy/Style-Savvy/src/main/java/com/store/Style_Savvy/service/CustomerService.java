package com.store.Style_Savvy.service;


import com.store.Style_Savvy.model.Customer;
import com.store.Style_Savvy.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository repository;

    public Customer save(Customer customer) {
        return repository.save(customer);
    }



    public List<Customer> getAll() {
        return repository.findAll();
    }

}
