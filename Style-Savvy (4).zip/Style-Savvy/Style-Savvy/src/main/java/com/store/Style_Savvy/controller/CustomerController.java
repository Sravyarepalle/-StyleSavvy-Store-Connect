package com.store.Style_Savvy.controller;





import com.store.Style_Savvy.model.Customer;
import com.store.Style_Savvy.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin("*")
@RequestMapping("/api")
public class CustomerController {

    @Autowired
    private CustomerService service;

    private static final String RECEIPT_DIR = "C:/receipts/";

    // Create (POST)
    @PostMapping("/customer")
    public Customer saveCustomer(@RequestParam String name,
                                 @RequestParam String mobile,
                                 @RequestParam double billAmount,
                                 @RequestParam String shoppingDate,
                                 @RequestParam String review,
                                 @RequestParam MultipartFile receipt) throws IOException {

        Files.createDirectories(Paths.get(RECEIPT_DIR));
        String receiptPath = RECEIPT_DIR + receipt.getOriginalFilename();
        Files.copy(receipt.getInputStream(), Paths.get(receiptPath), StandardCopyOption.REPLACE_EXISTING);

        Customer c = new Customer();
        c.setName(name);
        c.setMobile(mobile);
        c.setBillAmount(billAmount);
        c.setReview(review);
        c.setShoppingDate(new Date());
        c.setReceiptPath(receiptPath);

        return service.save(c);
    }

    // Read (GET all)
    @GetMapping("/customers")
    public List<Customer> getAllCustomers() {
        return service.getAll();
    }


    }

