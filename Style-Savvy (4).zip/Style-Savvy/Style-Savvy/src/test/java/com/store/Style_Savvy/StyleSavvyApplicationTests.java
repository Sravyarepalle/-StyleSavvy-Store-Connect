package com.store.Style_Savvy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StyleSavvyApplicationTests {

	@Test
	void contextLoads() {
	}

}
